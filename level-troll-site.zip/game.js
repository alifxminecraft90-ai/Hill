(function(){
const W=800,H=450,SP=3.4;
const $=id=>document.getElementById(id);
let C,X,L=0,lv,P,T,deaths=0,un=0,mode='play',fl=0,gf=0,started=0,G=.55,JV=-11.2,ice=0,pt=[];
const keys={l:0,r:0,j:0};
try{deaths=+localStorage.getItem('lt_d')||0;un=+localStorage.getItem('lt_p')||0}catch(e){}
const put=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
let AC;const cfg=()=>{try{return JSON.parse(localStorage.getItem('lt_s'))||{}}catch(e){return{}}};
function snd(a,b,d){if(cfg().sound===0)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const t=AC.currentTime,o=AC.createOscillator(),g=AC.createGain();o.type='square';o.frequency.setValueAtTime(a,t);o.frequency.exponentialRampToValueAtTime(b,t+d);g.gain.setValueAtTime(.07,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(AC.destination);o.start();o.stop(t+d)}catch(e){}}
function vib(){if(cfg().vib!==0&&typeof navigator!=='undefined'&&navigator.vibrate)navigator.vibrate(60)}
const R=(x,y,w,h,o)=>Object.assign({x,y,w,h},o);
const all=['pit','tpit','spike','pop','wall','stairs','fall','mv'];
const ST=[
{n:'Meadow',a:'#7cc8ff',b:'#d9f4ff',g:'#3a2f25',t:'#5acb4f',sp:'#e63946',pit:'#2a7de1',deco:'cloud',pool:['pit','tpit','spike','pop']},
{n:'Desert',a:'#ff9d3d',b:'#ffe6a8',g:'#6b3f1d',t:'#f0c060',sp:'#7a1f1f',pit:'#b5651d',deco:'sun',pool:['pit','tpit','spike','pop','wall','stairs','fall']},
{n:'Glacier',a:'#9ad8ff',b:'#f4fcff',g:'#2b4a63',t:'#e6f8ff',sp:'#2f6bff',pit:'#0b3d91',deco:'snow',ice:1,pool:['pit','tpit','spike','pop','wall','mv','fall']},
{n:'Inferno',a:'#2a0808',b:'#8a2412',g:'#1a0d0a',t:'#ff6a1a',sp:'#ffd166',pit:'#ff4500',deco:'ember',dk:1,pool:all},
{n:'Orbit',a:'#05051a',b:'#2c1d66',g:'#16123a',t:'#8a70ff',sp:'#ff4fa3',pit:'#000',deco:'star',lowg:1,dk:1,pool:all}
];
function rng(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function gen(i){
  const si=i/10|0,l=i%10,Tm=ST[si],r=rng(si*977+l*131+7);
  const n=1+[0,0,1,1,1,2,2,2,3,3][l],sw=500/n,k=[],f=[],tr=[],pits=[],ds=[R(720,320,36,60)];
  const pk=a=>a[r()*a.length|0];
  for(let j=0;j<n;j++){
    const cx=180+sw*(j+.5)+(r()-.5)*16,gw=Math.round(62+l*3.5+r()*10);
    const ty=(si==0&&l==0)?'tpit':pk(Tm.pool);
    if(ty=='pit')pits.push({x:cx-gw/2,w:gw});
    else if(ty=='tpit')pits.push({x:cx-gw/2,w:gw,t:1});
    else if(ty=='spike')k.push(R(cx-14,358,28+(r()*14|0),22));
    else if(ty=='pop'){const q=R(cx-15,356,30,24,{on:0});k.push(q);tr.push({x:[cx-95,9999],f:()=>{q.on=1}})}
    else if(ty=='wall'){const h=40+(r()*30|0);f.push(R(cx-20,380-h,40,h))}
    else if(ty=='stairs')f.push(R(cx-45,335,40,45),R(cx-5,290,50,90));
    else if(ty=='fall')k.push(R(cx-17,0,34,34,{dn:1,fall:1}));
    else k.push(R(cx,358,26,22,{mv:{a:cx-45,b:cx+45,v:1.6}}));
  }
  pits.sort((a,b)=>a.x-b.x);let x0=0;
  for(const p of pits){f.push(R(x0,380,p.x-x0,70));if(p.t){const q=R(p.x,380,p.w,70);f.push(q);tr.push({x:[p.x-75,9999],f:()=>{q.gone=1}})}x0=p.x+p.w}
  f.push(R(x0,380,800-x0,70));
  if(l%3==2)tr.push({x:[640,9999],f:q=>{q.ds[0].x=730;q.ds[0].y=250;q.f.push(R(690,310,110,16))}});
  else if(si>0&&l%4==3){ds.unshift(R(130,320,36,60,{fake:1}));ds[1].hid=1}
  return{s:[40,350],ds,f,k,tr};
}
function ld(i,h){
  L=i;T=ST[i/10|0];G=T.lowg?.4:.55;JV=T.lowg?-9.4:-11.2;ice=T.ice;
  lv=gen(i);lv.h=h||0;lv.t=lv.tr.map(()=>0);P={x:40,y:350,w:18,h:28,vx:0,vy:0,g:0};
  const r=rng(i+5);pt=Array.from({length:22},()=>({x:r()*W,y:r()*H*.8,v:.3+r()*.8,s:6+r()*14}));
}
const ov=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
function die(){deaths++;put('lt_d',deaths);fl=14;snd(220,40,.3);vib();ld(L,lv.h+1)}
function nxt(){snd(500,1100,.25);gf=12;if(L+1>un){un=L+1;put('lt_p',un)}if(L+1>=50){mode='win';return}ld(L+1)}
function step(){
  if(mode!=='play')return;
  const tv=(keys.r-keys.l)*SP;P.vx=ice?P.vx+(tv-P.vx)*.08:tv;
  if(keys.j&&P.g){P.vy=JV;snd(300,700,.12)}
  P.vy=Math.min(P.vy+G,14);
  P.x=Math.max(0,Math.min(W-P.w,P.x+P.vx));
  for(const f of lv.f)if(!f.gone&&ov(P,f)){if(P.vx>0)P.x=f.x-P.w;else if(P.vx<0)P.x=f.x+f.w}
  P.y+=P.vy;P.g=0;
  for(const f of lv.f)if(!f.gone&&ov(P,f)){if(P.vy>0){P.y=f.y-P.h;P.g=1}else P.y=f.y+f.h;P.vy=0}
  lv.tr.forEach((t,i)=>{if(!lv.t[i]&&P.x>=t.x[0]&&P.x<=t.x[1]){lv.t[i]=1;t.f(lv)}});
  for(const k of lv.k){
    if(k.mv){k.x+=k.mv.v;if(k.x<k.mv.a||k.x>k.mv.b)k.mv.v*=-1}
    if(k.fall&&!k.go){const d=k.x+k.w/2-(P.x+9);if(d<100&&d>-20)k.go=1}
    if(k.go){k.vy=(k.vy||0)+.7;k.y+=k.vy;if(k.y>380-k.h){k.y=380-k.h;k.go=0;k.fall=0}}
    if(k.on!==0&&ov(P,{x:k.x+4,y:k.y+4,w:k.w-8,h:k.h-8}))return die();
  }
  if(P.y>H+40)return die();
  for(const d of lv.ds)if(ov(P,d)){if(d.fake)return die();return nxt()}
}
function deco(){
  const k=T.deco,tm=performance.now()/1000;
  if(k==='sun'){X.fillStyle='#fff3b0';X.beginPath();X.arc(640,95,46,0,7);X.fill()}
  if(k==='star'){X.fillStyle='#ff4fa3';X.beginPath();X.arc(130,100,36,0,7);X.fill();X.fillStyle='rgba(0,0,0,.25)';X.beginPath();X.arc(142,92,30,0,7);X.fill()}
  for(const p of pt){
    if(k==='cloud'){p.x+=p.v*.4;if(p.x>W+60)p.x=-90;X.fillStyle='rgba(255,255,255,.85)';X.fillRect(p.x,p.y*.6,p.s*4,p.s*.9);X.fillRect(p.x+p.s,p.y*.6-p.s*.5,p.s*2,p.s)}
    else if(k==='sun'){p.x+=p.v*2;if(p.x>W)p.x=0;X.fillStyle='rgba(255,235,170,.7)';X.fillRect(p.x,p.y+60,3,3)}
    else if(k==='snow'){p.y+=p.v;p.x+=Math.sin(p.y/30)*.4;if(p.y>H)p.y=-5;X.fillStyle='#fff';X.beginPath();X.arc(p.x,p.y,p.s/5,0,7);X.fill()}
    else if(k==='ember'){p.y-=p.v;if(p.y<0)p.y=H;X.fillStyle='#ffb347';X.fillRect(p.x,p.y,3,3)}
    else{X.fillStyle='rgba(255,255,255,'+(.35+.65*Math.abs(Math.sin(tm*1.5+p.x)))+')';X.fillRect(p.x,p.y,2,2)}
  }
}
function draw(){
  const g=X.createLinearGradient(0,0,0,H);g.addColorStop(0,T.a);g.addColorStop(1,T.b);
  X.fillStyle=g;X.fillRect(0,0,W,H);deco();
  X.fillStyle=T.pit;X.fillRect(0,418,W,32);
  for(const f of lv.f)if(!f.gone){X.fillStyle=T.g;X.fillRect(f.x,f.y,f.w,f.h);X.fillStyle=T.t;X.fillRect(f.x,f.y,f.w,6)}
  for(const d of lv.ds){
    if(d.hid&&!lv.h)continue;
    X.fillStyle=d.hid?'rgba(139,69,19,.45)':'#8b4513';X.fillRect(d.x,d.y,d.w,d.h);
    X.strokeStyle='rgba(0,0,0,.55)';X.lineWidth=3;X.strokeRect(d.x+1.5,d.y+1.5,d.w-3,d.h-3);
    X.fillStyle='#ffd23f';X.fillRect(d.x+d.w-10,d.y+d.h/2,4,4);
  }
  X.fillStyle=T.sp;
  for(const k of lv.k){
    if(k.on===0)continue;
    const n=Math.max(1,Math.round(k.w/12)),w=k.w/n;
    for(let i=0;i<n;i++){
      X.beginPath();
      if(k.dn){X.moveTo(k.x+i*w,k.y);X.lineTo(k.x+(i+1)*w,k.y);X.lineTo(k.x+(i+.5)*w,k.y+k.h)}
      else{X.moveTo(k.x+i*w,k.y+k.h);X.lineTo(k.x+(i+1)*w,k.y+k.h);X.lineTo(k.x+(i+.5)*w,k.y)}
      X.fill();
    }
  }
  X.fillStyle='#000';X.fillRect(P.x,P.y+8,P.w,P.h-8);
  X.beginPath();X.arc(P.x+9,P.y+7,7,0,7);X.fill();
  X.fillStyle='#fff';X.fillRect(P.x+(keys.l?3:9),P.y+5,3,3);X.fillRect(P.x+(keys.l?9:13),P.y+5,3,3);
  X.fillStyle=T.dk?'#fff':'#111';X.font='bold 18px system-ui,sans-serif';
  X.fillText(T.n+'  '+(L%10+1)+'/10    ☠ '+deaths,16,28);
  if(fl>0){X.fillStyle='rgba(230,57,70,'+(fl/20)+')';X.fillRect(0,0,W,H);fl--}
  if(gf>0){X.fillStyle='rgba(80,220,120,'+(gf/30)+')';X.fillRect(0,0,W,H);gf--}
  if(mode==='win'){
    X.fillStyle='rgba(17,17,17,.9)';X.fillRect(0,0,W,H);X.fillStyle='#ffd23f';X.textAlign='center';
    X.font='bold 44px system-ui,sans-serif';X.fillText('You escaped all 50 levels!',W/2,190);
    X.font='22px system-ui,sans-serif';X.fillText('☠ '+deaths+' deaths',W/2,232);X.fillText('Tap to play again',W/2,272);X.textAlign='left';
  }
}
function fit(){const s=Math.min(innerWidth/W,innerHeight/H);C.style.width=W*s+'px';C.style.height=H*s+'px'}
let last=0,acc=0;
function loop(t){
  requestAnimationFrame(loop);
  acc+=Math.min(t-last,50);last=t;
  if(startGame.paused)acc=0;else while(acc>=16.667){step();acc-=16.667}
  draw();
}
function bind(id,k){
  const e=$(id),set=v=>ev=>{ev.preventDefault();keys[k]=v};
  e.addEventListener('pointerdown',set(1));
  ['pointerup','pointercancel','pointerleave'].forEach(t=>e.addEventListener(t,set(0)));
}
function startGame(i){
  mode='play';ld(i||0);
  if(started)return;started=1;
  C=$('c');X=C.getContext('2d');fit();
  addEventListener('resize',fit);
  bind('bl','l');bind('br','r');bind('bj','j');
  const kc={ArrowLeft:'l',KeyA:'l',ArrowRight:'r',KeyD:'r',ArrowUp:'j',KeyW:'j',Space:'j'};
  addEventListener('keydown',e=>{if(kc[e.code]){keys[kc[e.code]]=1;e.preventDefault()}});
  addEventListener('keyup',e=>{if(kc[e.code]){keys[kc[e.code]]=0;e.preventDefault()}});
  addEventListener('blur',()=>{keys.l=keys.r=keys.j=0});
  C.addEventListener('pointerdown',()=>{if(mode==='win'){mode='play';ld(0)}});
  try{screen.orientation.lock('landscape').catch(()=>{})}catch(e){}
  requestAnimationFrame(loop);
}
startGame.ST=ST;startGame.prog=()=>un;
startGame.reset=()=>{deaths=0;un=0;put('lt_d',0);put('lt_p',0)};
startGame.dbg=()=>({lv,P,L,mode,deaths});
window.startGame=startGame;
})();
